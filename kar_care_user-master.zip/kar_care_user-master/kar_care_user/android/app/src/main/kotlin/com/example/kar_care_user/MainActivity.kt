package com.example.kar_care_user

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

import 'package:flutter/material.dart';

var primaryColor = const Color(0xFF1C1C1C);
var buttonPrimaryColor = const Color(0xFF0182D9);
var buttonSeconadryColor = const Color(0xFF0045A1);

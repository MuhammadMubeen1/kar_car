class Wash {
  String title;
  bool value;
  Wash({
    required this.title,
    this.value = false,
  });
}
